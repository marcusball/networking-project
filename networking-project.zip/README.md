networking-project
==================

Peer-to-peer application for CNT 4007C. 

-----
**Note about compiling**  

Because I'm a bad person ad I enjoy wasting time doing things that aren't productive, this project has a library that you need to add to Eclipse in order to compile. This library, JAnsi, is commited, so just pull and you'll have it. 
You just need to add it to eclipse, now. In Eclipse, go to Project > Properties. In the window menu, select "Java Build Path", then click the "Libraries" tab. Use the "Add External JARs" button to open the jansi jar file that is in the "dependencies" folder of this repository. 

![Imgur](http://i.imgur.com/Gnhx1Mz.png)

-----
RUN!
====

java -cp bin/:dependencies/jansi-1.11.jar bitTorrentPkg.peerProcss 
