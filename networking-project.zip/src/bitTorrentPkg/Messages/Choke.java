package bitTorrentPkg.Messages;

public class Choke extends NormalMessage {
	public Choke(){
		this.messageType = 0;
	}
}
