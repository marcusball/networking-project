package bitTorrentPkg.Messages;

public class Interested extends NormalMessage {
	public Interested(){
		this.messageType = 2;
	}
}
