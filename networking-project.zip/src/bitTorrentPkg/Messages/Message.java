package bitTorrentPkg.Messages;

public interface Message {
	public byte[] toBytes();
}
