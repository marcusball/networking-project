package bitTorrentPkg.Messages;

public class NotInterested extends NormalMessage {
	public NotInterested(){
		this.messageType = 3;
	}
}
