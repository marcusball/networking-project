package bitTorrentPkg.Messages;

public class Unchoke extends NormalMessage {
	public Unchoke(){
		this.messageType = 1;
	}
}
